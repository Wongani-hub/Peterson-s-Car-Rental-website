// Mobile Navigation Toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(n => n.addEventListener('click', () => {
    hamburger.classList.remove('active');
    navMenu.classList.remove('active');
}));

// Navbar background change on scroll
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 100) {
        navbar.style.background = 'rgba(255, 255, 255, 0.98)';
        navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
    } else {
        navbar.style.background = 'rgba(255, 255, 255, 0.95)';
        navbar.style.boxShadow = 'none';
    }
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Payment Modal Functions
let currentCarData = {};

function openBookingModal(button) {
    const carCard = button.closest('.car-card');
    const carImage = carCard.querySelector('.car-image img').src;
    const carName = carCard.querySelector('h3').textContent;
    const carPrice = carCard.querySelector('.price').textContent;
    const carId = carCard.dataset.car;
    
    currentCarData = {
        id: carId,
        name: carName,
        price: parseInt(carPrice.replace('$', '')),
        image: carImage
    };
    
    // Populate modal with car details
    document.getElementById('modalCarImage').src = carImage;
    document.getElementById('modalCarName').textContent = carName;
    document.getElementById('modalCarPrice').textContent = carPrice + ' per day';
    document.getElementById('dailyRate').textContent = carPrice;
    
    // Set minimum dates
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    document.getElementById('pickupDate').min = tomorrow.toISOString().split('T')[0];
    document.getElementById('returnDate').min = tomorrow.toISOString().split('T')[0];
    
    // Show modal
    document.getElementById('bookingModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // Add event listeners for date changes
    document.getElementById('pickupDate').addEventListener('change', calculateTotal);
    document.getElementById('returnDate').addEventListener('change', calculateTotal);
    
    // Add card number formatting
    document.getElementById('cardNumber').addEventListener('input', formatCardNumber);
    document.getElementById('expiryDate').addEventListener('input', formatExpiryDate);
    document.getElementById('cvv').addEventListener('input', formatCVV);
}

function closeBookingModal() {
    document.getElementById('bookingModal').style.display = 'none';
    document.body.style.overflow = 'auto';
    document.getElementById('bookingForm').reset();
    currentCarData = {};
}

function calculateTotal() {
    const pickupDate = new Date(document.getElementById('pickupDate').value);
    const returnDate = new Date(document.getElementById('returnDate').value);
    
    if (pickupDate && returnDate && returnDate > pickupDate) {
        const timeDiff = returnDate.getTime() - pickupDate.getTime();
        const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
        
        const totalAmount = currentCarData.price * daysDiff;
        const depositAmount = Math.round(totalAmount * 0.6 * 100) / 100; // 60% deposit
        const remainingAmount = totalAmount - depositAmount;
        
        document.getElementById('numberOfDays').textContent = daysDiff;
        document.getElementById('totalAmount').textContent = '$' + totalAmount;
        document.getElementById('depositAmount').textContent = '$' + depositAmount;
        document.getElementById('remainingAmount').textContent = '$' + remainingAmount;
    } else {
        document.getElementById('numberOfDays').textContent = '0';
        document.getElementById('totalAmount').textContent = '$0';
        document.getElementById('depositAmount').textContent = '$0';
        document.getElementById('remainingAmount').textContent = '$0';
    }
}

function formatCardNumber(e) {
    let value = e.target.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
    e.target.value = formattedValue;
}

function formatExpiryDate(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) {
        value = value.slice(0, 2) + '/' + value.slice(2, 4);
    }
    e.target.value = value;
}

function formatCVV(e) {
    e.target.value = e.target.value.replace(/\D/g, '');
}

// Form submission handling
const contactForm = document.querySelector('.contact-form form');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(this);
        const name = this.querySelector('input[type="text"]').value;
        const email = this.querySelector('input[type="email"]').value;
        const phone = this.querySelector('input[type="tel"]').value;
        const car = this.querySelector('select').value;
        const message = this.querySelector('textarea').value;
        
        // Simple validation
        if (!name || !email || !car || !message) {
            showNotification('Please fill in all required fields', 'error');
            return;
        }
        
        // Simulate form submission
        showNotification('Thank you for your message! We will get back to you soon.', 'success');
        
        // Reset form
        this.reset();
    });
}

// Booking form submission
const bookingForm = document.getElementById('bookingForm');
if (bookingForm) {
    document.getElementById("bookingForm").addEventListener("submit", async (e) => {
        e.preventDefault();

        // Grab form data
        const formData = {
          name: e.target.name.value,
          email: e.target.email.value,
          phone: e.target.phone.value,
          car: e.target.car.value,
          message: e.target.message.value,
          bookingId: "BK-" + Date.now() // simple unique ID
        };

        try {
          const res = await fetch("http://localhost:5000/book", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData)
          });

          const data = await res.json();
          alert(data.message);
        } catch (err) {
          console.error("Error:", err);
          alert("Something went wrong. Please try again.");
        }
    });
}

function sendConfirmationEmail(bookingData) {
    console.log('Starting email sending process...');
    console.log('EmailJS available:', typeof emailjs !== 'undefined');
    
    // Check if EmailJS is loaded
    if (typeof emailjs === 'undefined') {
        console.error('EmailJS is not loaded!');
        showNotification('Email service not available. Please contact support.', 'error');
        return;
    }
    
    // Check if EmailJS is initialized
    if (!emailjs.init) {
        console.error('EmailJS is not properly initialized!');
        showNotification('Email service not properly initialized. Please refresh the page.', 'error');
        return;
    }
    
    // Prepare email template parameters
    const templateParams = {
        to_name: `${bookingData.firstName} ${bookingData.lastName}`,
        to_email: bookingData.email,
        from_name: 'Peterson\'s Car Rentals',
        from_email: 'noreply@petersonscarrentals.com',
        subject: 'Car Reservation Confirmation - ' + bookingData.carName,
        message: `Thank you for your car reservation!
        
Car Details:
- Car: ${bookingData.carName}
- Pickup Date: ${formatDate(bookingData.pickupDate)}
- Pickup Time: ${formatTime(bookingData.pickupTime)}
- Return Date: ${formatDate(bookingData.returnDate)}
- Return Time: ${formatTime(bookingData.returnTime)}
- Total Amount: ${bookingData.totalAmount}
- Deposit Paid (60%): ${bookingData.depositAmount}
- Remaining Balance: ${bookingData.remainingAmount}

Customer Information:
- Name: ${bookingData.firstName} ${bookingData.lastName}
- Email: ${bookingData.email}
- Phone: ${bookingData.phone}

IMPORTANT: Your reservation is confirmed with a 60% deposit. The remaining balance of ${bookingData.remainingAmount} must be paid when you collect the car.

Pickup Instructions:
- Please arrive 15 minutes before your scheduled pickup time
- Bring your driver's license and the credit card used for deposit
- Pay the remaining balance when collecting the car
- Complete the vehicle inspection checklist
- Sign the rental agreement

If you have any questions, please contact us at +1 (555) 123-4567.

Best regards,
Peterson's Car Rentals Team`,
        
        // Alternative template variables (in case your template uses different names)
        customer_name: `${bookingData.firstName} ${bookingData.lastName}`,
        customer_email: bookingData.email,
        customer_phone: bookingData.phone,
        car_name: bookingData.carName,
        pickup_date: formatDate(bookingData.pickupDate),
        pickup_time: formatTime(bookingData.pickupTime),
        return_date: formatDate(bookingData.returnDate),
        return_time: formatTime(bookingData.returnTime),
        total_amount: bookingData.totalAmount,
        deposit_amount: bookingData.depositAmount,
        remaining_amount: bookingData.remainingAmount,
        company_name: 'Peterson\'s Car Rentals',
        company_phone: '+1 (555) 123-4567',
        company_address: '123 Business District, City Center, State 12345'
    };
    
    console.log('Template parameters:', templateParams);
    console.log('Sending email with service_cz3plan and template_w8uyhzr');
    
    // Show loading notification
    showNotification('Sending confirmation email...', 'info');
    
    // Send email using EmailJS
    emailjs.send('service_cz3plan', 'template_w8uyhzr', templateParams)
        .then(function(response) {
            console.log('Email sent successfully:', response);
            showNotification('Confirmation email sent to ' + bookingData.email, 'success');
        }, function(error) {
            console.error('Email failed to send:', error);
            console.error('Error details:', {
                status: error.status,
                text: error.text,
                response: error.response,
                templateParams: templateParams
            });
            
            // More specific error messages
            let errorMessage = 'Email failed to send';
            if (error.status === 422) {
                errorMessage = 'Email template error (422). Please check template variables.';
            } else if (error.status === 400) {
                errorMessage = 'Bad request (400). Please check EmailJS configuration.';
            } else if (error.status === 401) {
                errorMessage = 'Unauthorized (401). Please check EmailJS credentials.';
            } else if (error.status === 500) {
                errorMessage = 'Server error (500). Please try again later.';
            }
            
            showNotification(errorMessage + ': ' + error.text, 'error');
        });
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

function formatTime(timeString) {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
}

function showSuccessModal() {
    // Populate success modal with booking details
    document.getElementById('successCarName').textContent = currentCarData.name;
    document.getElementById('successPickupDate').textContent = formatDate(document.getElementById('pickupDate').value);
    document.getElementById('successPickupTime').textContent = formatTime(document.getElementById('pickupTime').value);
    document.getElementById('successTotalAmount').textContent = document.getElementById('totalAmount').textContent;
    document.getElementById('successDepositAmount').textContent = document.getElementById('depositAmount').textContent;
    document.getElementById('successRemainingAmount').textContent = document.getElementById('remainingAmount').textContent;
    
    // Show success modal
    document.getElementById('successModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeSuccessModal() {
    document.getElementById('successModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Close modals when clicking outside
window.addEventListener('click', function(event) {
    const bookingModal = document.getElementById('bookingModal');
    const successModal = document.getElementById('successModal');
    
    if (event.target === bookingModal) {
        closeBookingModal();
    }
    
    if (event.target === successModal) {
        closeSuccessModal();
    }
});

// Notification system
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close">&times;</button>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease;
    `;
    
    // Add animation keyframes
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Add to page
    document.body.appendChild(notification);
    
    // Close button functionality
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    });
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Intersection Observer for simple animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements for animation
document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll('.car-card, .feature, .contact-item');
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
    
    // Set minimum dates for date inputs
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        input.min = tomorrow.toISOString().split('T')[0];
    });
    
    // Test EmailJS initialization
    console.log('Page loaded, checking EmailJS...');
    if (typeof emailjs !== 'undefined') {
        console.log('EmailJS is loaded successfully');
        console.log('EmailJS version:', emailjs.version);
    } else {
        console.error('EmailJS failed to load!');
    }
});

// Add loading animation to images
document.addEventListener('DOMContentLoaded', () => {
    const images = document.querySelectorAll('img');
    
    images.forEach(img => {
        img.addEventListener('load', function() {
            this.style.opacity = '1';
        });
        
        img.addEventListener('error', function() {
            this.style.opacity = '0.5';
            this.style.filter = 'grayscale(100%)';
        });
    });
});

// Simple parallax effect for hero section
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const hero = document.querySelector('.hero');
    if (hero) {
        const rate = scrolled * -0.3;
        hero.style.transform = `translateY(${rate}px)`;
    }
});

// Simple hover effects for car cards
document.addEventListener('DOMContentLoaded', () => {
    const carCards = document.querySelectorAll('.car-card');
    
    carCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});

// Counter animation for prices
function animateCounter(element, target, duration = 1000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    const timer = setInterval(() => {
        start += increment;
        if (start >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(start);
        }
    }, 16);
}

// Test EmailJS functionality
function testEmailJS() {
    console.log('Testing EmailJS connection...');
    
    // Check if EmailJS is loaded
    if (typeof emailjs === 'undefined') {
        console.error('EmailJS is not loaded!');
        showNotification('EmailJS is not loaded. Please check the library.', 'error');
        return;
    }
    
    // Check if EmailJS is initialized
    if (!emailjs.init) {
        console.error('EmailJS is not properly initialized!');
        showNotification('EmailJS is not properly initialized.', 'error');
        return;
    }
    
    console.log('EmailJS is loaded and initialized');
    
    // Test email with sample data
    const testParams = {
        to_name: 'Test User',
        to_email: 'test@example.com',
        from_name: 'Peterson\'s Car Rentals',
        from_email: 'noreply@petersonscarrentals.com',
        subject: 'Test Email - Car Rental Confirmation',
        message: 'This is a test email to verify EmailJS functionality.',
        
        // Alternative template variables
        customer_name: 'Test User',
        customer_email: 'test@example.com',
        customer_phone: '+1234567890',
        car_name: 'Test Car',
        pickup_date: 'Monday, January 1, 2024',
        pickup_time: '9:00 AM',
        return_date: 'Tuesday, January 2, 2024',
        total_amount: '$100',
        company_name: 'Peterson\'s Car Rentals',
        company_phone: '+1 (555) 123-4567',
        company_address: '123 Business District, City Center, State 12345'
    };
    
    console.log('Sending test email...');
    showNotification('Sending test email...', 'info');
    
    emailjs.send('service_cz3plan', 'template_w8uyhzr', testParams)
        .then(function(response) {
            console.log('Test email sent successfully:', response);
            showNotification('Test email sent successfully! Check your EmailJS dashboard.', 'success');
        }, function(error) {
            console.error('Test email failed:', error);
            showNotification('Test email failed: ' + error.text, 'error');
        });
}

// Initialize counter animation when cars section comes into view
const carsSection = document.querySelector('.cars-section');
if (carsSection) {
    const priceObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const prices = entry.target.querySelectorAll('.price');
                prices.forEach(price => {
                    const targetPrice = parseInt(price.textContent.replace('$', ''));
                    price.textContent = '$0';
                    setTimeout(() => {
                        animateCounter(price, targetPrice);
                    }, 500);
                });
                priceObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    priceObserver.observe(carsSection);
}
