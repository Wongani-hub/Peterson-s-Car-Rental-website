import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import nodemailer from "nodemailer";

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Gmail transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "yourgmail@gmail.com",
    pass: "your-app-password" // ⚠️ not your main password, use Google App Password
  }
});

// Endpoint
app.post("/book", async (req, res) => {
  const { name, email, phone, car, message, bookingId } = req.body;

  try {
    await transporter.sendMail({
      from: `"Car Rentals" <yourgmail@gmail.com>`,
      to: email,
      subject: `Booking Confirmation - Ref: ${bookingId}`,
      html: `
        <h2>Hello ${name},</h2>
        <p>Thank you for booking with us! Here are your booking details:</p>
        <ul>
          <li><b>Car:</b> ${car}</li>
          <li><b>Phone:</b> ${phone}</li>
          <li><b>Message:</b> ${message}</li>
          <li><b>Booking ID:</b> ${bookingId}</li>
        </ul>
        <p>We look forward to serving you 🚗</p>
      `
    });

    res.json({ success: true, message: "Booking confirmed & email sent ✅" });
  } catch (err) {
    console.error("Email error:", err);
    res.status(500).json({ success: false, message: "Failed to send email" });
  }
});

app.listen(5000, () => console.log("🚀 Server running on http://localhost:5000"));
